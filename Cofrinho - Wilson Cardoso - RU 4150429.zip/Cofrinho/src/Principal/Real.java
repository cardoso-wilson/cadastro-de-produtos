//Wilson Cardoso RU 4150429

package Principal;
public class Real extends Moeda {
	
	
	//Criação da String para receber os valores
	Real (float d) {
		super(d);
	}
	
	
	void info() {
		System.out.println("------------");
		System.out.println("Real: "+getDado());
	}
	
	
	public float somarmoedas() {
		return (dado);
	}
	
	
	public void somar (float dado) {
		this.dado = dado;
	}
}