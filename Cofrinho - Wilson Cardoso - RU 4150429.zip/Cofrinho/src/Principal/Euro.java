//Wilson Cardoso RU 4150429

package Principal;
public class Euro extends Moeda {

	
	//Cria a String para receber os valores
	Euro(float d) {
		super(d);
	}

	
	void info() {
		System.out.println("------------");
		System.out.println("Euro: "+getDado());
	}
	
	
	//faz a conversão do euro para o real
	public float somarmoedas() {
		return (float) ((dado)*5.17);
	}
	
	
	public void somar (float dado) {
		this.dado = dado;
	}
}