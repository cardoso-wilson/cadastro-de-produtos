//Wilson Cardoso RU 4150429

package Principal;
abstract public class Moeda  {
	
	
	//Cria a String para receber as moedas
	float dado;
	Moeda (float d){
	dado=d;
	}
	
	
	public float getDado() {
		return dado;
	}

	
	abstract void info();

	public void somar (float dado) {
		this.dado = dado;
	}
	
	
	public float somarmoedas() {
		return (dado);
	}
	
}