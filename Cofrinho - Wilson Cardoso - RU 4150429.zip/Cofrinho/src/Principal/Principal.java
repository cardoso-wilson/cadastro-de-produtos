//Wilson Cardoso RU 4150429

package Principal;

//Importa as bibliotecas
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
	
	
	// Cria o ArrayList e cria as variáveis
	public static void main (String [] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<Moeda> lista = new ArrayList <Moeda>();
		int selecao = 0;
		int looping = 1;
		
		
		// Inicia o looping do cofrinho com as opções para o usuário escolher
		System.out.println("Bem-vindo ao Cofrinho de moedas do Wilson Cardoso (RU 4150429)");
		while (looping >= 1) {
			System.out.println("----------------");
			System.out.println("Cofrinho:");
			System.out.println("1 - Adicionar Moeda");
			System.out.println("2 - Remover Moedas");
			System.out.println("3 - Listar Moedas");
			System.out.println("4 - Calcular total convertido para Real");
			System.out.println("0 - Encerrar");
			System.out.println(">>> ");
			selecao = Integer.parseInt(scan.nextLine());
	
			
			// Inicia a ação selecionada pelo usuário (seleção 1) para adicionar as moedas
			if (selecao == 1) {
						
				//Selecionar a moeda que o usuário escolher
				System.out.println("----------------");
				System.out.println("1 - Real");
				System.out.println("2 - Dolar");
				System.out.println("3 - Euro");
				System.out.println("Escolha Moeda: ");
				System.out.println(">>> ");
				selecao = Integer.parseInt(scan.nextLine());
				
				
				// Insere o valor da moeda "REAL" na lista
				if (selecao == 1) {
					System.out.println("----------------");
					System.out.println("Digite o valor: ");
					System.out.println(">>> ");
					Scanner teclado = new Scanner(System.in);
					Float v = teclado.nextFloat();
					lista.add(new Real (v));
				}

				
				// Insere o valor da moeda "DOLAR" na lista
				else if (selecao == 2) {
					System.out.println("----------------");
					System.out.println("Digite o valor: ");
					System.out.println(">>> ");
					Scanner teclado = new Scanner(System.in);
					Float v = teclado.nextFloat();
					lista.add(new Dolar (v));
				}

				
				// Insere o valor da moeda "EURO" na lista
				else if (selecao == 3) {
					System.out.println("----------------");
					System.out.println("Digite o valor: ");
					System.out.println(">>> ");
					Scanner teclado = new Scanner(System.in);
					Float v = teclado.nextFloat();
					lista.add(new Euro (v));
				}
				
			
				// Caso o usuario selecione uma opção inválida, voltao ao inicio
				else {
					 System.out.println("Selecione somente 1, 2 e 3");
				}
			}
	
			
			// Inicia a ação selecionada pelo usuário (seleção 2) para excluir as moedas
			else if (selecao == 2) {
				
				int teclado = 0;
				int i = 0;

				// Lista as moedas para exclusão
				for (Moeda o : lista ) {
					System.out.printf("Posicao %d\n", i);
					i ++;
					o.info();
					System.out.println("___________________"); 
				}
				
					// Seleciona a moeda a ser excluída
					System.out.printf("\nInforme a posicao para excluir:\n");
					System.out.println(">>> ");
					teclado = Integer.parseInt(scan.nextLine());
					lista.remove(teclado);
			}		
			
			
			// Inicia a ação selecionada pelo usuário (seleção 3) para listar as moedas
			else if (selecao == 3) { 
				for (Moeda o : lista ) {
					  o.info();	  
				}
			}
			
			
			// Inicia a ação selecionada pelo usuário (seleção 4) para somar as moedas e converter para o real
			else if (selecao == 4) {
				float soma = 0;
				for (Moeda o : lista ) {
					  soma += o.somarmoedas();
				}
				System.out.println("----------------");
				System.out.println("Total convertido para Real R$"+soma);
			}
			
			
			// Fim do programa
			else if (selecao == 0) {
				looping = 0;
				System.out.println("----------------");
				System.out.println("Fim do Programa");
			}
			
			
			// Caso o usuario selecione uma opçâo inválida, volta ao inicio
			else {
				System.out.println("----------------");
				System.out.println("Selecione somente 0, 1, 2, 3 e 4");	
			}
						
		}
 
 	}
		
}