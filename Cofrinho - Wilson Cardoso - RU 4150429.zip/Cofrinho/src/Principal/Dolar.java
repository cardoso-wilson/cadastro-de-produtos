//Wilson Cardoso RU 4150429

package Principal;
public class Dolar extends Moeda {

	
	//Cria a String para receber os valores
	Dolar(float d) {
		super(d);
	}
	

	void info() {
		System.out.println("------------");
		System.out.println("Dolar: "+getDado());
	} 
	
	
	//faz a conversão do dolar para o real
	public float somarmoedas() {
		return (float) ((dado)*5.24);
	}
	
	
	public void somar (float dado) {
		this.dado = dado;
	}
}